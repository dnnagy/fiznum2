//
//  main.c
//  bead4
//
//  Created by Nagy Daniel on 2017. 05. 05..
//  Copyright © 2017. Nagy Daniel. All rights reserved.
//
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <math.h>

#define T long double
#define EPSILON 1e-9 // Ennel kisebb elemeket nem engedunk a foatloba !!
#define nduint unsigned long int
#define SWAPD(U,X,Y) {U aux = (X); (X) = (Y); (Y) = aux;}
#define ABS(X) ((X) > 0 ? (X) : (-(X)))

#ifndef DEBUG_LN
#define DEBUG_LN(X, ...) printf((X), ##__VA_ARGS__);printf("\n");
#endif


//Differential equation: dy/dx = diff_ptr(x,y), y = f(x).
typedef T (*diff_ptr)(T, T);

//Differential equation system: dx1/dt = diff_sys_ptr[0](t, x1, x2, ...); dx2/dt = diff_sys_ptr[1](t, x1, x2, ...) ...
//If we have a system of N equations, each function should have N+2 params. The N+2nd is N.
typedef T (**diff_sys_ptr)(T*, nduint);

// Calculate RK4 step of equation
T rk4_step(T xn, T yn,T h, diff_ptr F){
    T k1 = h*F(xn, yn);
    T k2 = h*F(xn + h/2.0, yn + k1/2.0);
    T k3 = h*F(xn + h/2.0, yn + k2/2.0);
    T k4 = h*F(xn + h, yn + k3);
    
    T ynp1 = yn + (1.0/6.0)*(k1 + 2*k2 + 2*k3 + k4);
    return ynp1;
};

//Solve a simple equation
void solve_RK4(diff_ptr F, T x0, T xn, T y0, nduint steps, const char* outputFileName){
    
    T xk = x0;
    T yk = y0;
    T h = (xn - x0)/steps;
    
    FILE* optr = fopen(outputFileName, "w");
    
    nduint i=0;
    while (i<steps) {
        yk = rk4_step(xk, yk, h, F);
        xk = xk+h;
        DEBUG_LN("step %lu: %Lf %Lf", i, xk, yk);
        fprintf(optr, "%Lf %Lf\n", xk, yk);
        i++;
    }
    fclose(optr);
    return;
};

// Calculate RK4 step of the system
T* rk4_sys_step(T* xn, T h, diff_sys_ptr system, nduint nEq){
    nduint nParam = nEq+1;
    T* xnp1 = malloc(nEq*sizeof(T));
    
    T* k1 = malloc(nEq*sizeof(T));
    T* k2 = malloc(nEq*sizeof(T));
    T* k3 = malloc(nEq*sizeof(T));
    T* k4 = malloc(nEq*sizeof(T));
    
    T* x_buf = malloc(nParam*sizeof(T)); // Use this to calculate k2,k3,k4 from xn and k1
    
    for (int i=0; i<nEq; i++) {
        k1[i] = h*system[i](xn, nParam);
    }
    
    x_buf[0] = xn[0] + h/2.0;
    for (int j=1; j<nParam; j++) {
        x_buf[j] = xn[j] + k1[j]/2.0;
    }
    
    for (int i=0; i<nEq; i++) {
        k2[i] = h*system[i](x_buf, nParam);
    }
    
    x_buf[0] = xn[0] + h/2.0;
    for (int j=1; j<nParam; j++) {
        x_buf[j] = xn[j] + k2[j]/2.0;
    }
    
    for (int i=0; i<nEq; i++) {
        k3[i] = h*system[i](x_buf, nParam);
    }
    
    x_buf[0] = xn[0] + h;
    for (int j=1; j<nParam; j++) {
        x_buf[j] = xn[j] + k3[j];
    }
    
    for (int i=0; i<nEq; i++) {
        k4[i] = h*system[i](x_buf, nParam);
    }
    
    for (int i=0; i<nParam; i++) {
        xnp1[i] = xn[i] + (1.0/6.0)*(k1[i] + 2*k2[i] + 2*k3[i] + k4[i]);
    }
    
    free(xn); //Free memory allocated in the last step
    return xnp1;
}

T func(T x, T y){
    return 1 - sin(x)*x*x;
}

int main(int argc, const char * argv[]) {
    diff_ptr eq = &func;
    
    solve_RK4(eq, 0, 4, 0, 5000, "output.dat");
    return 0;
}
